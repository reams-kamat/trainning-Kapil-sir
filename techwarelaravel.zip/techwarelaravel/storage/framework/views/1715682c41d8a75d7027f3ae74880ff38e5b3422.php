<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    You are logged in!
                    <!-- Button trigger modal -->
                    <a href="<?php echo e(URL::to('/')); ?>/home/student/create">Add Student</a>
                    <form method="POST" action="<?php echo e(URL::to('/')); ?>/home/student/store">
            <input type="hidden" name="_token" class="token" value="<?php echo e(csrf_token()); ?>">

            <div class="form-group<?php echo e($errors->has('fullname') ? ' has-error' : ''); ?>">
                <label for="fullname" class="col-md-4 control-label">Fullname</label>
                <div class="col-md-6">
                    <input id="fullname" type="text" class="form-control" name="fullname" value="<?php echo e(old('fullname')); ?>">

                    <?php if($errors->has('fullname')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('fullname')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
          <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
            <label for="address">Address</label>
            <input type="text" class="form-control" id="address" name="address" placeholder="Address">
            <?php if($errors->has('address')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('address')); ?></strong>
                        </span>
                    <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-default">Submit</button>
        </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>