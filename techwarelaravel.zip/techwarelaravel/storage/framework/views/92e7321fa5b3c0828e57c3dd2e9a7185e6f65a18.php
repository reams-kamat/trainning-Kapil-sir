
<?php $__env->startSection('content'); ?>
<div id="about" class="about-box">
    <div class="about-a1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="title-box">
                        <h2><?php echo e($name1); ?> <span>&</span><?php echo e($name2); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row align-items-center about-main-info">
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="about-m">
                                <div class="about-img">
                                    <img class="img-fluid" src="<?php echo e(URL::to('/')); ?>/images/about-img-01.jpg" alt="" />
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <h2> <i class="fa fa-heart-o" aria-hidden="true"></i> <span><?php echo e($student->fullname); ?></span> <i class="fa fa-heart-o" aria-hidden="true"></i></h2>
                            <p><?php echo e($student->address); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>