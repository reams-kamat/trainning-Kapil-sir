<!DOCTYPE html>
<html>
<head>
	<title>Kapil</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h1>Laravel Home</h1>
		<a href="<?php echo e(URL::to('/')); ?>">Home</a>
		<a href="<?php echo e(URL::to('/')); ?>/contact">Contact</a>
		<a href="<?php echo e(URL::to('/')); ?>/himal">Himal</a>
	</div>
</body>

<script type="text/javascript" src="<?php echo e(URL::to('/')); ?>/js/bootstrap.min.js"></script>
</html>