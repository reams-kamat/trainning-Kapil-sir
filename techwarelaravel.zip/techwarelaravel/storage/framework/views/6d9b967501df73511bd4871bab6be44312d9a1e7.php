<?php $__env->startSection('content'); ?>
<div class="home-slider">
    <ul class="rslides">
        <li><img src="images/slider-01.jpg" alt=""></li>
        <li><img src="images/slider-02.jpg" alt=""></li>
        <li><img src="images/slider-03.jpg" alt=""></li>
    </ul>
    <div class="lbox-details">
        <h1>Karlene Hoard  & Jonas Pare</h1>
        <h2>We're getting married</h3>
        <div class="countdown main-time clearfix">
            <div id="timer">
                <h3> 5 July 2017</h3>
                <div id="days"></div>
                <div id="hours"></div>
                <div id="minutes"></div>
                <div id="seconds"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>