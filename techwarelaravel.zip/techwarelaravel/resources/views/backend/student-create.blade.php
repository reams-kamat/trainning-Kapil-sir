@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    You are logged in!
                    <!-- Button trigger modal -->
                    <a href="{{URL::to('/')}}/home/student/create">Add Student</a>
                    <form method="POST" action="{{URL::to('/')}}/home/student/store">
            <input type="hidden" name="_token" class="token" value="{{ csrf_token() }}">

            <div class="form-group{{ $errors->has('fullname') ? ' has-error' : '' }}">
                <label for="fullname" class="col-md-4 control-label">Fullname</label>
                <div class="col-md-6">
                    <input id="fullname" type="text" class="form-control" name="fullname" value="{{ old('fullname') }}">

                    @if ($errors->has('fullname'))
                        <span class="help-block">
                            <strong>{{ $errors->first('fullname') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
          <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
            <label for="address">Address</label>
            <input type="text" class="form-control" id="address" name="address" placeholder="Address">
            @if ($errors->has('address'))
                        <span class="help-block">
                            <strong>{{ $errors->first('address') }}</strong>
                        </span>
                    @endif
          </div>
          <button type="submit" class="btn btn-default">Submit</button>
        </form>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection