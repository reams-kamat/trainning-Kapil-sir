<!DOCTYPE html>
<html>
<head>
	<title>Kapil</title>
	<link rel="stylesheet" type="text/css" href="{{URL::to('/')}}/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h1>Laravel Contact</h1>
		<a href="{{URL::to('/')}}">Home</a>
		<a href="{{URL::to('/')}}/contact">Contact</a>
		<a href="{{URL::to('/')}}/himal">Himal</a>
		{{$name}} {{$address}} {{$sum}}
		<div class="row">
			<div class="col-md-6">
				<form class="form-horizontal" action="{{URL::to('/')}}/contact/store" method="POST">
					{{csrf_field()}}
					<div class="form-group">
						<label for="name" class="col-sm-2 control-label">Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="name" placeholder="Please enter your name" required="true" name="name">
						</div>
					</div>
					<div class="form-group">
						<label for="address" class="col-sm-2 control-label">Address</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="address" placeholder="Please enter your address" required="true" name="address">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default">Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>

<script type="text/javascript" src="{{URL::to('/')}}/js/bootstrap.min.js"></script>
</html>