<!DOCTYPE html>
<html>
<head>
	<title>Kapil</title>
	<link rel="stylesheet" type="text/css" href="{{URL::to('/')}}/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h1>Laravel Home</h1>
		<a href="{{URL::to('/')}}">Home</a>
		<a href="{{URL::to('/')}}/contact">Contact</a>
		<a href="{{URL::to('/')}}/himal">Himal</a>
	</div>
</body>

<script type="text/javascript" src="{{URL::to('/')}}/js/bootstrap.min.js"></script>
</html>