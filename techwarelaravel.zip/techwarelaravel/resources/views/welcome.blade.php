@extends('main')
@section('content')
<div class="home-slider">
    <ul class="rslides">
        <li><img src="images/slider-01.jpg" alt=""></li>
        <li><img src="images/slider-02.jpg" alt=""></li>
        <li><img src="images/slider-03.jpg" alt=""></li>
    </ul>
    <div class="lbox-details">
        <h1>Karlene Hoard  & Jonas Pare</h1>
        <h2>We're getting married</h3>
        <div class="countdown main-time clearfix">
            <div id="timer">
                <h3> 5 July 2017</h3>
                <div id="days"></div>
                <div id="hours"></div>
                <div id="minutes"></div>
                <div id="seconds"></div>
            </div>
        </div>
    </div>
</div>
@endsection