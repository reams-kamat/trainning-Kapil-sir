<!DOCTYPE html>
<html>
<head>
	<title>afd</title>
</head>
<body>
<h1>Laravel Himal</h1>
		<a href="{{URL::to('/')}}">Home</a>
		<a href="{{URL::to('/')}}/contact">Contact</a>
		<a href="{{URL::to('/')}}/himal">Himal</a>
</body>
</html>