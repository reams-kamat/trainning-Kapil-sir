<!DOCTYPE html>
<html>
<head>
	<title>binita</title>
	<link rel="stylesheet" type="text/css" href="{{URL::to('/')}}/css/app.css">
</head>
<body>
<h1> My name is Binita Niroula</h1>
</body>
</html>