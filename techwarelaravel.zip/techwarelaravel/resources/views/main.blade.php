<!DOCTYPE html>
<html>
<head>
	<title>Welcome home</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
hello everyone
</body>
</html>