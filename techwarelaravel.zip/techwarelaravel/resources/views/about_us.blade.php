@extends('main')
@section('content')
<div id="about" class="about-box">
    <div class="about-a1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="title-box">
                        <h2>{{ $name1 }} <span>&</span>{{$name2}}</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    @foreach($students as $student)
                    <div class="row align-items-center about-main-info">
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="about-m">
                                <div class="about-img">
                                    <img class="img-fluid" src="{{URL::to('/')}}/images/about-img-01.jpg" alt="" />
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <h2> <i class="fa fa-heart-o" aria-hidden="true"></i> <span>{{$student->fullname}}</span> <i class="fa fa-heart-o" aria-hidden="true"></i></h2>
                            <p>{{$student->address}}</p>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection