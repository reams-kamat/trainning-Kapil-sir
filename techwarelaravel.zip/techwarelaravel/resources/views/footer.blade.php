<footer class="footer-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="footer-company-name">All Rights Reserved. &copy; 2018 <a href="#">Techware</a> Design By : <a href="http://www.techware.com.np">html design</a></p>
            </div>
        </div>
    </div>
</footer>